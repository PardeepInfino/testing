## Release notes

*Magento_SaaSProductVariant* module
