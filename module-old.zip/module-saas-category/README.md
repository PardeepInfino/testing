## Release notes

*Magento_SaaSCategory* module
