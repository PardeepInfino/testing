## Release notes

*Magento_ProductVariantDataExporter* module
